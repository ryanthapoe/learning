package HitungPostfix;

public class Stack {

    double[] item;
    int top;

    public Stack(int size) {
        item = new double[size];
        top = -1;
    }

    public boolean isFull() {
        return top == item.length - 1;
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public void push(double value) {
        if (!isFull()) {
            item[++top] = value;
        } else {
            System.out.println("Stack is full!");
        }
    }

    public double pop() {
        if (!isEmpty()) {
            return item[top--];
        } else {
            System.out.println("Stack is empty!");
            return -99;
        }
    }

    public double top() {
        if (!isEmpty()) {
            return item[top];
        } else {
            System.out.println("Stack is empty!");
            return -99;
        }
    }
}