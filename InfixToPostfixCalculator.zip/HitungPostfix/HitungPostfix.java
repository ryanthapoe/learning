package HitungPostfix;

public class HitungPostfix {

    public static void main(String[] args) {
        String in = "2,2,3,+,*,3,2,-,*";
        String[] res = in.split(",");
        char[] resC = new char[res.length];
        for (int i = 0; i < res.length; i++) {
            resC[i] = res[i].charAt(0);
        }
        System.out.println(hitungPostfix(resC));
    }

    public static double hitungPostfix(char[] postfix) {
        char[] in = new char[postfix.length + 1];
        System.arraycopy(postfix, 0, in, 0, postfix.length);
        in[in.length - 1] = ')';
        Stack stack = new Stack(1000);
        for (int i = 0; i < in.length; i++) {
            if (isNumber(in[i])) {
                double data = Character.getNumericValue(in[i]);
                stack.push(data);
            } else if (isOperator(in[i])) {
                double op1 = stack.pop();
                double op2 = stack.pop();
                double hasil = 0;
                if (in[i] == '*') {
                    hasil = op2 * op1;
                } else if (in[i] == '/') {
                    hasil = op2 / op1;
                } else if (in[i] == '+') {
                    hasil = op2 + op1;
                } else if (in[i] == '-') {
                    hasil = op2 - op1;
                } else if (in[i] == '^') {
                    hasil = Math.pow(op2, op1);
                }
                stack.push(hasil);
            }
        }
        return stack.pop();
    }

    public static boolean isNumber(char in) {
        return (in >= '0' && in <= '9');
    }

    public static boolean isOperator(char input) {
        return input == '*' || input == '/' || input == '+' || input == '-' || input == '^';
    }
}
