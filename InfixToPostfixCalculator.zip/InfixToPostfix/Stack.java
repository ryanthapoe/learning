package InfixToPostfix;

public class Stack {

    char[] item;
    int top;

    public Stack(int size) {
        item = new char[size];
        top = -1;
    }

    public boolean isFull() {
        return top == item.length - 1;
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public void push(char value) {
        if (!isFull()) {
            item[++top] = value;
        } else {
            System.out.println("Stack is full!");
        }
    }

    public char pop() {
        if (!isEmpty()) {
            return item[top--];
        } else {
            System.out.println("Stack is empty!");
            return 0;
        }
    }

    public char top() {
        if (!isEmpty()) {
            return item[top];
        } else {
            System.out.println("Stack is empty!");
            return 0;
        }
    }
}