package InfixToPostfix;

import java.util.Scanner;

public class InfixNotation {

    Stack stack;
    String output;
    String infix;

    public InfixNotation(String infixNotation) {
        stack = new Stack(1000);
        output = "";
        infix = infixNotation;
    }

    public String getPostfix() {
        String infix = this.infix + ")";
        for (int j = 0; j < infix.length(); j++) {
            char ch = infix.charAt(j);
            switch (ch) {
                case '+':
                case '-':
                    checkOperator(ch, 1);
                    break;
                case '*':
                case '/':
                    checkOperator(ch, 2);
                    break;
                case '^':
                    checkOperator(ch, 3);
                    break;
                case '(':
                    stack.push(ch);
                    break;
                case ')':
                    getParentheses(ch);
                    break;
                default:
                    output = output + ch;
                    break;
            }
        }
        return output;
    }

    public void checkOperator(char opIn, int prio1) {
        while (!stack.isEmpty()) {
            char opTop = stack.pop();
            if (opTop == '(') {
                stack.push(opTop);
                break;
            } else {
                int prio2;
                if (opTop == '^') {
                    prio2 = 3;
                } else if (opTop == '*' || opTop == '/') {
                    prio2 = 2;
                } else {
                    prio2 = 1;
                }
                if (prio2 >= prio1) {
                    output += opTop;
                } else {
                    stack.push(opTop);
                    break;
                }
            }
        }
        stack.push(opIn);
    }

    public void getParentheses(char ch) {
        while (!stack.isEmpty()) {
            char check = stack.pop();
            if (check == '(') {
                break;
            } else {
                output += check;
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Program untuk merubah notasi infix ke notasi postfix\n"
                + "Contoh : Notasi Infix (A+B)*C diubah menjadi AB+C*");
        System.out.print("Masukkan notasi infix = ");
        String input = sc.next();
        InfixNotation ifx = new InfixNotation(input);
        System.out.println(ifx.getPostfix());
    }
}
